import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketAddress;
import java.net.SocketTimeoutException;
import java.nio.ByteBuffer;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import java.io.*;



class TftpClient
{
	public static void main(String args[])
	{
		if(args.length == 3)
		{
			TftpUtil tftpUtil = new TftpUtil();

			String hostName = args[0];
			String port = args[1];
			String fileName = args[2];

			try
			{
				DatagramSocket clientDS = new DatagramSocket();
				File file = new File(fileName);

				if(file.exists())
				{
					InetAddress DestinationIP = InetAddress.getByName(hostName);
					int DestPortNumber = Integer.parseInt(port);
					byte[] fileConvert = fileName.getBytes();


					//RRQ 

					DatagramPacket RRQPacket = tftpUtil.packRRQDatagramPacket(fileConvert);
					RRQPacket.setAddress(DestinationIP);
					RRQPacket.setPort(DestPortNumber);
		  		clientDS.send(RRQPacket);

		  		//ACK 

		  		//create a buffer to store data
					byte[] buf = new byte[514];

					DatagramPacket dp = new DatagramPacket(buf, 514);

					byte[] ACKByte = new byte[1];
					byte expected = 1;

					FileOutputStream fout = new FileOutputStream("Copy_" + fileName);
		   		BufferedOutputStream bout = new BufferedOutputStream(fout);

		  		while(true)
		  		{
						//waiting for DatagramPacket from client
						clientDS.receive(dp); //blocking

						int packet = dp.getLength();

						ACKByte[0] = tftpUtil.extractACKNumber(dp);

						byte[] recivedPacket = dp.getData();
						if(ACKByte[0] == expected) {
							bout.write(recivedPacket, 2, packet - 2);
							expected++;
						}



						ACKByte[0] = tftpUtil.extractACKNumber(dp);

						DatagramPacket ACKPacket = tftpUtil.packACKDatagramPacket(ACKByte);

						ACKPacket.setAddress(DestinationIP);

						ACKPacket.setPort(dp.getPort());

						clientDS.send(ACKPacket);



						if(packet < 514)
						{
							break;
						}
		  		}

		  		bout.flush();
		   		bout.close();
		   		fout.close();

		  		System.out.println("SUCCESS");

		  		clientDS.close();

				}
				else
				{
					System.out.println('"' + fileName + '"'  + " does not exist");
				}
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		else
		{
			System.err.println("\nIncorrect Format. Please follow example below:\n\njava TftpClient <Host_Name> <Host_Port_Number> <File_Name>\n");
		}
	}

}
