
import java.net.*;
import java.io.*;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;


class HelloWorldServerRunnable implements Runnable 
{
    Socket client;

    @Override 
    public void run()
    {
	try {
	    BufferedReader reader =
		new BufferedReader(
                new InputStreamReader(client.getInputStream()));
	    String line = reader.readLine();
	    
	    BufferedWriter writer = new
				BufferedWriter(new OutputStreamWriter(client.getOutputStream()));		
		writer.write("You said: " + line+"\n");
		writer.flush();
	    client.close();
	}
	catch(Exception e) {
	    System.err.println("Exception: " + e);
	}
    }

    public HelloWorldServerRunnable(Socket s)
    {
	client = s;
    }
}

public class HelloWorldServer3 {
	private static final ExecutorService exec =  Executors.newFixedThreadPool(10); 

    public static void main(String args[])
    {
	try {
	    ServerSocket ss = new ServerSocket(51234);
	    while(true) {
		Socket client = ss.accept();
		HelloWorldServerRunnable task =
		    new HelloWorldServerRunnable(client);
		 exec.execute(task);    	
	    }
	}
	catch(Exception e) {
	    System.err.println("Exception: " + e);
	}
    }
}

