import java.net.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.io.*;
public class HttpServer {
	private static final ExecutorService exec =  Executors.newFixedThreadPool(10); 
	public static void main(String[] args) throws IOException{
		//Q. 3.1 server is listening on port 
		ServerSocket ss = new ServerSocket(51234);
		System.out.println("web server starting...");
		System.out.println("Host Port: " + ss.getLocalPort());
		try {
		while(true) {
		// socket object to receive incoming client requests
		Socket client = ss.accept(); //Q3.2
		//System.out.println("connection is made by ip address: " + client.getInetAddress().getHostAddress());
		HttpServerSession task = new HttpServerSession(client);
		 exec.execute(task); 
			 
		}
		} catch (Exception e) {
			System.err.println("Error: " + e);
		}
	}
}
	
class HttpServerSession implements Runnable{ //Q.3.2 Accept a connection
	private Socket client;
	public HttpServerSession (Socket s){
	client = s;
	}
	@Override
	public void run() {	
		try { //Q.3.3 Look at the HTTP request
			BufferedReader reader = new BufferedReader(new InputStreamReader(client.getInputStream())); 
			BufferedOutputStream writer = new BufferedOutputStream(client.getOutputStream());
				
			InetAddress ip = client.getInetAddress();
			System.out.println("Connection recieved from: " + ip.getHostAddress());				
			String line = reader.readLine();
			//System.out.println(line);

			//Q. 3.4 Extract the filename
			String data[] = line.split(" ");
			if(data.length == 3){
				if(data[0].compareTo("GET") == 0){
					String fName = data[1].substring(1);  //to remove the forward slash
					System.out.println(fName);

					//Q. 3.5 send response
					File temp = new File(fName);
					if(temp.exists()){
						writeln(writer,"HTTP/1.1 200 OK");
						writeln(writer,"");
						//writeln(writer,"Hello World");//
						System.out.println("Requested file Found");
						input(writer, fName);
						
					}
					//Q. 3.9 Selected extentions

					else if(fName.length() == 0){
						writeln(writer,"HTTP/1.1 200 OK");
						writeln(writer,"");
						System.out.println("Returning to default page ....");
						input(writer, "panda.jpeg");
					}
					else{
						//Q.3.7 Deal with missing files
						writeln(writer,"HTTP/1.1 404 File Not Found");
						System.out.println("file not found");
					}
				}
			}
			writer.flush();
			reader.close();
			writer.close();
			client.close();
		}
		catch(Exception e) {
			   System.err.println("Error: " + e);
		}
	
	}
		//Q.3.6 Return the file
		private void input(BufferedOutputStream writer, String fileName) {
			try{
				byte[] buf = new byte[1024];
				FileInputStream in = new FileInputStream(fileName);
				int rc = in.read(buf);
				while (rc != -1){
					writer.write(buf, 0,rc);
					writer.flush();
					//Q.3.8 Running over a slow line
					//Thread.currentThread().sleep(1000);
					rc = in.read(buf);
				}
				in.close();
			}
			catch(Exception e){
				System.err.println("Filename not found:" + e);
			}
			
		}
		//Q.3.5 Send back a response
		private void writeln(BufferedOutputStream out, String file) throws IOException {
			String news = file + "\r\n";
			byte[] array = news.getBytes();
			for(int i=0; i<array.length; i++){
				out.write(array[i]);
			}
			return;
			
		} 
}

