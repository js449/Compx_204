import java.net.*;
import java.io.*;


class HelloWorldServerThread extends Thread
{
    Socket client;

    public void run()
    {
	try {
	    BufferedReader reader =
		new BufferedReader(
                new InputStreamReader(client.getInputStream()));
	    String line = reader.readLine();
	    
	    BufferedWriter writer = new
				BufferedWriter(new OutputStreamWriter(client.getOutputStream()));		
		writer.write("You said: " + line+"\n");
		writer.flush();
	    client.close();
	}
	catch(Exception e) {
	    System.err.println("Exception: " + e);
	}
    }

    public HelloWorldServerThread(Socket s)
    {
	client = s;
    }
}

public class HelloWorldServer2 {

    public static void main(String args[])
    {
	try {
	    ServerSocket ss = new ServerSocket(51234);
	    while(true) {
		Socket client = ss.accept();
		HelloWorldServerThread thread =
		    new HelloWorldServerThread(client);

		thread.start();
	    }
	}
	catch(Exception e) {
	    System.err.println("Exception: " + e);
	}
    }
}



