class Sleepy extends Thread
{
    public Sleepy()
    {
    }

    public void run()
    {
	try {
	    System.out.println("Sleepy: hello");
	    sleep(1000);
	    System.out.println("Sleepy: 1.0 seconds");
	    sleep(1000);
	    System.out.println("Sleepy: 2.0 seconds");
	    sleep(1000);
	    System.out.println("Sleepy: 3.0 seconds");
	    sleep(1000);
	    System.out.println("Sleepy: 4.0 seconds");
	    sleep(1000);
	    System.out.println("Sleepy: 5.0 seconds");
	    sleep(1000);
	    System.out.println("Sleepy: 6.0 seconds");
	    System.out.println("Sleepy: bye");
	} catch(Exception e) {
	    System.err.println("Sleepy Exception: " + e);
	}
    }
}

class Snoozy extends Thread
{
    public Snoozy()
    {
    }

    public void run()
    {
	try {
	    System.out.println("Snoozy: hello");
	    sleep(1500);
	    System.out.println("Snoozy: 1.5 seconds");
	    sleep(1000);
	    System.out.println("Snoozy: 2.5 seconds");
	    sleep(1000);
	    System.out.println("Snoozy: 3.5 seconds");
	    sleep(1000);
	    System.out.println("Snoozy: 4.5 seconds");
	    sleep(1000);
	    System.out.println("Snoozy: 5.5 seconds");
	    sleep(1000);
	    System.out.println("Snoozy: 6.5 seconds");
	    System.out.println("Snoozy: bye");
	}
	catch(Exception e) {
	    System.err.println("Snoozy Exception: " + e);
	}
    }
}

class SleepyThreads
{
    public static void main(String args[])
    {
	Sleepy sleepy = new Sleepy();
	Snoozy snoozy = new Snoozy();
	sleepy.start();
	snoozy.start();
	System.out.println("now waiting...");
    }
}
