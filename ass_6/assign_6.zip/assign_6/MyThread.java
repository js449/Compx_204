import java.net.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import java.lang.Object;
import java.net.DatagramSocket;
import java.net.MulticastSocket;

public class MyThread implements Runnable
{

	public void run()
	{
		try{
			//Give the Adderess
			InetAddress group_addr = InetAddress.getByName("239.0.202.1");

			//Multicast Socket that listen on port 40202
			MulticastSocket multisocket = new MulticastSocket(40202);
			
			//Join the Group
			multisocket.joinGroup(group_addr);

			while(true){
				 // to get responses(recieve messages)
				 byte[] bufBytes = new byte[1024];
				 DatagramPacket recv_packet = new DatagramPacket(bufBytes, bufBytes.length);
				 multisocket.receive(recv_packet);

				//string method to encode and decode an array of bytes(for the datapackets send and recieve)
			         String received = new String(recv_packet.getData(), 0, recv_packet.getLength());
			         System.out.println("Message Arrived: " + received);

				
				 
			}


		}
		catch(Exception ex){
			//To Catch error from unexpected file coming though
			System.err.println("Unexpected File: error..." + ex);
		}

	}

}

