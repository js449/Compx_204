import java.net.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import java.lang.Object;
import java.net.DatagramSocket;
import java.net.MulticastSocket;

public class ChatClient
{
	private static final ExecutorService executor_s = Executors.newFixedThreadPool(10);
	
	public static void main(String args[]) throws IOException
	{
		
		//Give the Adderess
		InetAddress group_addr = InetAddress.getByName("239.0.202.1");

		//Multicast Socket that listen on port 40202
		MulticastSocket multisocket = new MulticastSocket(40202);

		MyThread new_task = new MyThread();
		executor_s.execute(new_task);
		
		 
		try{
			
			//Join the Group
			multisocket.joinGroup(group_addr);
			while(true){
				//read line of text from keyboard
				String input = System.console().readLine();
								
				//Encapsulate the data and send as a packet
				DatagramPacket dpacket = new DatagramPacket(input.getBytes(), input.length(), group_addr, 40202);
			 	multisocket.send(dpacket);
			}
		}
		catch(Exception ex){
			//To Catch error from unexpected file coming though
			System.err.println("Unexpected File: error..." + ex);
		}

	}

}

